"""
Supply Chain Project Configuration
"""
from pathlib import Path

# === PATHS ===
RAW_DATA_PATH = Path("H:/My Drive/supply_chain_enterprise")
PROJECT_PATH = Path("C:/Users/Manu/supply_chain_project")

# Data layers
BRONZE_PATH = PROJECT_PATH / "data" / "bronze"
SILVER_PATH = PROJECT_PATH / "data" / "silver"
GOLD_PATH = PROJECT_PATH / "data" / "gold"

# DuckDB warehouse
WAREHOUSE_PATH = PROJECT_PATH / "data" / "warehouse.duckdb"

# === RAW DATA FILES ===
RAW_FILES = {
    # Master data
    "suppliers": RAW_DATA_PATH / "suppliers.parquet",
    "products": RAW_DATA_PATH / "products.parquet",
    "locations": RAW_DATA_PATH / "locations.parquet",
    "carriers": RAW_DATA_PATH / "carriers.parquet",
    "supplier_product_map": RAW_DATA_PATH / "supplier_product_map.parquet",
    
    # Transactional (single files)
    "purchase_orders": RAW_DATA_PATH / "purchase_orders.parquet",
    "shipments": RAW_DATA_PATH / "shipments.parquet",
    "production_orders": RAW_DATA_PATH / "production_orders.parquet",
    
    # Partitioned data (directories)
    "sales": RAW_DATA_PATH / "sales",
    "demand_forecasts": RAW_DATA_PATH / "demand_forecasts",
    "inventory": RAW_DATA_PATH / "inventory",
}

# === TABLE SCHEMAS ===
DATE_COLUMNS = {
    "sales": ["date"],
    "demand_forecasts": ["forecast_date"],
    "inventory": ["snapshot_date"],
    "purchase_orders": ["order_date", "expected_date", "actual_date"],
    "shipments": ["planned_ship_date", "actual_ship_date", "planned_delivery_date", "actual_delivery_date"],
    "production_orders": ["planned_date", "completion_date"],
}

# === VALIDATION THRESHOLDS ===
QUALITY_THRESHOLDS = {
    "max_null_pct": 0.10,  # Max 10% nulls in non-nullable columns
    "max_duplicate_pct": 0.02,  # Max 2% duplicates
}
