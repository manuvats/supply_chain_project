-- Staged products with derived fields
{{ config(materialized='table') }}

SELECT
    sku,
    product_name,
    category,
    sub_category,
    brand,
    unit_cost,
    unit_price,
    unit_price - unit_cost AS unit_margin,
    ROUND((unit_price - unit_cost) / unit_price * 100, 2) AS margin_pct,
    unit_weight_kg,
    volume_cm3,
    shelf_life_days,
    is_hazardous,
    is_perishable,
    abc_class,
    xyz_class,
    CONCAT(abc_class, xyz_class) AS abc_xyz_class,
    safety_stock_days,
    CURRENT_TIMESTAMP AS _loaded_at
FROM {{ read_delta('products') }}
