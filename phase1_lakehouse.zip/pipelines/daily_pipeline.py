"""
Supply Chain ETL Pipeline
Orchestrates Bronze → Silver → Gold data flow.
"""
from prefect import flow, task
from pathlib import Path
import subprocess
import sys
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PROJECT_PATH, BRONZE_PATH

@task(name="ingest-bronze", retries=2)
def ingest_bronze():
    """Load raw data into Bronze layer"""
    print("Loading Bronze layer...")
    from src.ingestion.load_bronze import load_bronze_layer, verify_bronze_layer
    load_bronze_layer()
    verify_bronze_layer()
    return True

@task(name="validate-bronze")
def validate_bronze():
    """Run data quality checks on Bronze layer"""
    print("Validating Bronze layer...")
    from src.quality.validate_bronze import run_quality_checks
    success = run_quality_checks()
    if not success:
        raise Exception("Data quality checks failed!")
    return True

@task(name="run-dbt-silver")
def run_dbt_silver():
    """Run dbt Silver models"""
    print("Running dbt Silver models...")
    dbt_path = PROJECT_PATH / "dbt_project"
    
    result = subprocess.run(
        ["dbt", "run", "--select", "silver.*"],
        cwd=str(dbt_path),
        capture_output=True,
        text=True
    )
    
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
        raise Exception("dbt Silver run failed!")
    
    return True

@task(name="run-dbt-gold")
def run_dbt_gold():
    """Run dbt Gold models"""
    print("Running dbt Gold models...")
    dbt_path = PROJECT_PATH / "dbt_project"
    
    result = subprocess.run(
        ["dbt", "run", "--select", "gold.*"],
        cwd=str(dbt_path),
        capture_output=True,
        text=True
    )
    
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
        raise Exception("dbt Gold run failed!")
    
    return True

@task(name="run-dbt-tests")
def run_dbt_tests():
    """Run dbt tests"""
    print("Running dbt tests...")
    dbt_path = PROJECT_PATH / "dbt_project"
    
    result = subprocess.run(
        ["dbt", "test"],
        cwd=str(dbt_path),
        capture_output=True,
        text=True
    )
    
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
        raise Exception("dbt tests failed!")
    
    return True

@task(name="generate-docs")
def generate_docs():
    """Generate dbt docs"""
    print("Generating dbt docs...")
    dbt_path = PROJECT_PATH / "dbt_project"
    
    subprocess.run(
        ["dbt", "docs", "generate"],
        cwd=str(dbt_path),
        capture_output=True
    )
    
    return True

@flow(name="supply-chain-daily-etl", log_prints=True)
def daily_etl_pipeline(skip_bronze: bool = False):
    """
    Daily ETL Pipeline
    
    Args:
        skip_bronze: Skip Bronze ingestion (use existing data)
    """
    print("=" * 60)
    print("SUPPLY CHAIN DAILY ETL PIPELINE")
    print("=" * 60)
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Step 1: Bronze ingestion
    if not skip_bronze:
        ingest_bronze()
    else:
        print("Skipping Bronze ingestion (using existing data)")
    
    # Step 2: Validate Bronze
    validate_bronze()
    
    # Step 3: Silver transformations
    run_dbt_silver()
    
    # Step 4: Gold aggregations
    run_dbt_gold()
    
    # Step 5: Run tests
    run_dbt_tests()
    
    # Step 6: Generate docs
    generate_docs()
    
    print()
    print("=" * 60)
    print("✅ PIPELINE COMPLETE")
    print("=" * 60)
    print(f"Finished: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

@flow(name="supply-chain-bronze-only", log_prints=True)
def bronze_only_pipeline():
    """Run Bronze ingestion and validation only"""
    print("Running Bronze-only pipeline...")
    ingest_bronze()
    validate_bronze()
    print("✅ Bronze pipeline complete")

@flow(name="supply-chain-transform-only", log_prints=True)
def transform_only_pipeline():
    """Run dbt transformations only (assumes Bronze exists)"""
    print("Running transform-only pipeline...")
    run_dbt_silver()
    run_dbt_gold()
    run_dbt_tests()
    generate_docs()
    print("✅ Transform pipeline complete")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Supply Chain ETL Pipeline")
    parser.add_argument("--skip-bronze", action="store_true", 
                        help="Skip Bronze ingestion")
    parser.add_argument("--bronze-only", action="store_true",
                        help="Run Bronze ingestion only")
    parser.add_argument("--transform-only", action="store_true",
                        help="Run transformations only")
    
    args = parser.parse_args()
    
    if args.bronze_only:
        bronze_only_pipeline()
    elif args.transform_only:
        transform_only_pipeline()
    else:
        daily_etl_pipeline(skip_bronze=args.skip_bronze)
