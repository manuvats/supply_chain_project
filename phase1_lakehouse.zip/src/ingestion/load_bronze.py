"""
Bronze Layer Ingestion
Loads raw parquet from Google Drive into local Delta Lake tables.
"""
import pandas as pd
import duckdb
from pathlib import Path
from datetime import datetime
from deltalake import write_deltalake, DeltaTable
import sys

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import RAW_DATA_PATH, BRONZE_PATH, RAW_FILES, DATE_COLUMNS

def load_single_parquet(name: str, path: Path) -> pd.DataFrame:
    """Load a single parquet file"""
    print(f"  Loading {name}...")
    df = pd.read_parquet(path)
    
    # Parse date columns
    if name in DATE_COLUMNS:
        for col in DATE_COLUMNS[name]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors='coerce')
    
    return df

def load_partitioned_parquet(name: str, path: Path) -> pd.DataFrame:
    """Load partitioned parquet files from a directory"""
    print(f"  Loading {name}/ (partitioned)...")
    
    files = sorted(path.glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No parquet files found in {path}")
    
    dfs = []
    for f in files:
        df = pd.read_parquet(f)
        dfs.append(df)
        print(f"    ✓ {f.name}: {len(df):,} rows")
    
    combined = pd.concat(dfs, ignore_index=True)
    
    # Parse date columns
    if name in DATE_COLUMNS:
        for col in DATE_COLUMNS[name]:
            if col in combined.columns:
                combined[col] = pd.to_datetime(combined[col], errors='coerce')
    
    return combined

def write_to_delta(df: pd.DataFrame, name: str, bronze_path: Path):
    """Write DataFrame to Delta Lake"""
    table_path = bronze_path / name
    
    # Write to Delta
    write_deltalake(
        str(table_path),
        df,
        mode="overwrite",
        engine="rust"
    )
    
    # Get stats
    dt = DeltaTable(str(table_path))
    print(f"  ✓ {name}: {len(df):,} rows → {table_path}")

def load_bronze_layer():
    """Main ingestion function"""
    print("=" * 60)
    print("BRONZE LAYER INGESTION")
    print("=" * 60)
    print(f"Source: {RAW_DATA_PATH}")
    print(f"Target: {BRONZE_PATH}")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Create bronze directory
    BRONZE_PATH.mkdir(parents=True, exist_ok=True)
    
    # Master data (single files)
    master_tables = ["suppliers", "products", "locations", "carriers", "supplier_product_map"]
    
    print("[1/3] Loading master data...")
    for name in master_tables:
        df = load_single_parquet(name, RAW_FILES[name])
        write_to_delta(df, name, BRONZE_PATH)
    
    # Transactional data (single files)
    transaction_tables = ["purchase_orders", "shipments", "production_orders"]
    
    print("\n[2/3] Loading transactional data...")
    for name in transaction_tables:
        df = load_single_parquet(name, RAW_FILES[name])
        write_to_delta(df, name, BRONZE_PATH)
    
    # Partitioned data (directories)
    partitioned_tables = ["sales", "demand_forecasts", "inventory"]
    
    print("\n[3/3] Loading partitioned data...")
    for name in partitioned_tables:
        df = load_partitioned_parquet(name, RAW_FILES[name])
        write_to_delta(df, name, BRONZE_PATH)
    
    print("\n" + "=" * 60)
    print("✅ BRONZE LAYER COMPLETE")
    print("=" * 60)
    
    # Summary
    print("\nTable Summary:")
    for table_dir in sorted(BRONZE_PATH.iterdir()):
        if table_dir.is_dir():
            dt = DeltaTable(str(table_dir))
            size_mb = sum(f.stat().st_size for f in table_dir.glob("*.parquet")) / 1e6
            print(f"  {table_dir.name}: {size_mb:.1f} MB")

def verify_bronze_layer():
    """Verify Bronze layer with DuckDB"""
    print("\n" + "=" * 60)
    print("VERIFICATION")
    print("=" * 60)
    
    con = duckdb.connect()
    
    tables = ["suppliers", "products", "locations", "sales", "inventory"]
    
    for table in tables:
        table_path = BRONZE_PATH / table
        if table_path.exists():
            result = con.execute(f"""
                SELECT COUNT(*) as cnt 
                FROM delta_scan('{table_path}')
            """).fetchone()
            print(f"  {table}: {result[0]:,} rows")

if __name__ == "__main__":
    load_bronze_layer()
    verify_bronze_layer()
