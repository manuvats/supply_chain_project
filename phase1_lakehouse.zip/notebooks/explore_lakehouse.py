"""
Lakehouse Exploration Script
Quick verification of all layers using DuckDB.
"""
import duckdb
from pathlib import Path

# Paths
BRONZE_PATH = Path("C:/Users/Manu/supply_chain_project/data/bronze")
WAREHOUSE_PATH = Path("C:/Users/Manu/supply_chain_project/data/warehouse.duckdb")

def explore_bronze():
    """Explore Bronze layer (Delta Lake)"""
    print("=" * 60)
    print("BRONZE LAYER (Delta Lake)")
    print("=" * 60)
    
    con = duckdb.connect()
    
    tables = ["suppliers", "products", "locations", "sales", "inventory"]
    
    for table in tables:
        table_path = BRONZE_PATH / table
        if table_path.exists():
            result = con.execute(f"""
                SELECT COUNT(*) as cnt 
                FROM delta_scan('{table_path}')
            """).fetchone()
            print(f"  {table}: {result[0]:,} rows")
    
    # Sample query
    print("\nTop 5 Products by ABC Class:")
    print(con.execute(f"""
        SELECT abc_class, COUNT(*) as cnt
        FROM delta_scan('{BRONZE_PATH}/products')
        GROUP BY abc_class
        ORDER BY abc_class
    """).df())

def explore_warehouse():
    """Explore DuckDB Warehouse (Silver/Gold)"""
    print("\n" + "=" * 60)
    print("WAREHOUSE (DuckDB - Silver/Gold)")
    print("=" * 60)
    
    if not WAREHOUSE_PATH.exists():
        print("Warehouse not found. Run dbt first.")
        return
    
    con = duckdb.connect(str(WAREHOUSE_PATH))
    
    # List tables
    tables = con.execute("SHOW TABLES").fetchall()
    print("\nTables:")
    for t in tables:
        count = con.execute(f"SELECT COUNT(*) FROM {t[0]}").fetchone()[0]
        print(f"  {t[0]}: {count:,} rows")
    
    # Sample queries
    print("\n--- Sample: Monthly Revenue Trend ---")
    print(con.execute("""
        SELECT 
            month_start,
            ROUND(SUM(total_revenue), 2) as revenue,
            SUM(total_units) as units
        FROM gold.fct_monthly_sales
        GROUP BY month_start
        ORDER BY month_start
        LIMIT 12
    """).df())
    
    print("\n--- Sample: Top 10 Products by Revenue ---")
    print(con.execute("""
        SELECT 
            sku,
            product_name,
            abc_class,
            ROUND(lifetime_revenue, 2) as revenue,
            ROUND(service_level, 2) as service_level
        FROM gold.dim_product_performance
        ORDER BY lifetime_revenue DESC
        LIMIT 10
    """).df())

def run_sample_queries():
    """Run some analytical queries"""
    print("\n" + "=" * 60)
    print("SAMPLE ANALYTICS")
    print("=" * 60)
    
    con = duckdb.connect()
    
    # Cross-layer query: Bronze sales + products
    print("\n--- Revenue by Category (from Bronze) ---")
    print(con.execute(f"""
        SELECT 
            p.category,
            ROUND(SUM(s.revenue), 2) as total_revenue,
            SUM(s.units_sold) as total_units
        FROM delta_scan('{BRONZE_PATH}/sales') s
        JOIN delta_scan('{BRONZE_PATH}/products') p ON s.sku = p.sku
        GROUP BY p.category
        ORDER BY total_revenue DESC
        LIMIT 10
    """).df())
    
    print("\n--- Stockout Rate by Store (from Bronze) ---")
    print(con.execute(f"""
        SELECT 
            store_id,
            COUNT(*) as total_days,
            SUM(CASE WHEN stockout_flag THEN 1 ELSE 0 END) as stockout_days,
            ROUND(SUM(CASE WHEN stockout_flag THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as stockout_rate
        FROM delta_scan('{BRONZE_PATH}/sales')
        GROUP BY store_id
        ORDER BY stockout_rate DESC
        LIMIT 10
    """).df())


if __name__ == "__main__":
    explore_bronze()
    explore_warehouse()
    run_sample_queries()
